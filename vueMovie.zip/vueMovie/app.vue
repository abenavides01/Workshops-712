<template>
  <NuxtLayout/>
</template>
